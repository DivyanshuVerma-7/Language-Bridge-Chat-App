# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause
